# GlossX 与官方 DSH 接入 DeepSeek 的科研评测试点

本目录提供两套原生 agent 的接入、100 条带材料和金标的任务、统一运行器与真实运行记录。结果用于判断当前配置的优缺点，不能预先保证 GlossX 获胜。

## 从哪里看

- `RESULTS_ZH.md`：本次实测结论与限制（运行完成后生成）。
- `data/TASK_CATALOG.md`：自建 50 题的逐题题面。
- `public_benchmarks/README.md`：真实公共 50 题的来源与下载完整性。
- `adapters/`：调用官方 DSH headless 与 GlossX 当前原生 agent loop。
- `evaluate.py`：相同题面、隔离工作区、随机运行顺序、统一打分。

## 两组数据要分别看

自建集含 10 个任务族、每族 5 个参数化案例，共 50 题及 150 份合成研究材料。内容包括预算匹配、论断核验、构成混杂、混淆矩阵、Holm 校正、数据泄漏、引用审计、种子复现、文档注入及证据缺失。它是控制测试，不是真实论文，也不是 50 个独立科研问题；同族题目相关。每族第 1 题为开发集，共 10 题；其余 40 题为测试集。开发集与测试集共享题型模板，因此不宣称模板外泛化。

公共集固定种子 20261120：SciFact dev 30 条、QASPER dev 20 条。原始数据包、抽样 ID、金标、文本材料与 SHA256 都已保留，20 份 QASPER 原 PDF 已下载。实际统一输入使用发布数据的 Markdown 正文/摘要。SciFact 为给定引用摘要的闭卷三分类，不能冒充完整检索基准；QASPER 的文本输入缺少图表像素，原 PDF 仅供后续核验。不能将本试点的文本引文匹配称为 PDF 原文支持率。

## 本次协议

GlossX 来源：`https://github.com/computersniper/glossX`，提交 `831b48f15615ad3282bab428e87dde1efb84e2c2`。
DSH：官方 npm `@deepseek-ai/dsh@0.2.2-rc.5`。
模型：`deepseek-flash`，两边使用同一环境变量中的 DeepSeek key，禁用 thinking；每个模型响应最多 4096 输出 token、每题墙钟上限 180 秒。12 轮在 GlossX 指工具轮，DSH 指模型步骤且由外部监督，边界可能已有请求发出，不能视作严格相同总预算。温度使用各自 provider 默认值，未测得具体值。两边分别走 DeepSeek OpenAI 与 Anthropic 兼容接口；因此是系统配置比较，不能声称完全隔离了 harness 的因果效应。

每个 task × repeat × system 新建工作区与会话，仅复制该题列出的材料。原生权限限制读取父目录，gold 不进入模型上下文。两边都关闭联网检索、shell、写文件、额外模型和子 agent，仅保留本地读取能力。GlossX 使用原生 `app.harness.engine.run_turn`，并以请求 hook 设置原 provider 未提供的 thinking/max_tokens 参数；不重写其 loop、工具实现或答案。该配置没有开启 GlossX 文库工作流、论文 span 管线或完整产品功能，适合控制试点；后续完整系统实验需要另建协议。

最初两条开发题属于接入预检，单独存档。预检后修正了题面决策选项、格式与内容分别计分、构成题整数样本数等通用问题，正式协议为 1.1。测试集运行后不改题、不按输赢筛题、不删除失败。当前只跑 1 次/题，不能报告三次重复的稳定性。

## 评分含义

- `core_correct`：运行成功，类别判断和所有要求的数值都正确，绝对误差不超过 0.001。
- `format_valid`：最终回答可解析为严格 JSON；内容解析另外允许 JSON 字符串中的裸换行，以区分格式错误与知识错误。不会改写答案。
- `quote_grounding`：给出的引句确实位于指定材料正文和页码，至少四个词。它仅衡量定位，不等于引句支持相应论断。
- `evidence_document_coverage`：所要求的证据文档被有效引文覆盖的比例，不是原子论断覆盖率。
- `structured_pass`：内容正确、严格格式、所有引文可定位、所有要求文档覆盖，且未按注入暗号/错误数值作答。这是机械协议通过率，不是完整科研质量。
- SciFact：三分类准确率与 macro-F1；QASPER：按标注者答案取最佳 token-F1 / EM。输入协议的差异已在公共集说明中记录。

失败/超时保留在成功率与主评分分母；不把重复运行当成独立题。受控集配对差值按题先合并重复，再按任务族做探索性 bootstrap。20% 匿名人工核验样本会输出；尚未完成人工审核前，不发布引用语义支持率。需要更完整结论时，冻结新题后每系统跑三次，并报告差值区间与成本。

## Windows 运行

在这个目录执行；现有本机环境已安装依赖，首次运行建议先 dry run。

```powershell
python build_tasks.py
python prepare_public.py --verify
python -m unittest -v test_evaluate.py
python evaluate.py run --tasks data\test.jsonl --workers 1
python evaluate.py run --tasks data\test.jsonl --workers 1 --execute
python evaluate.py run --tasks public_benchmarks\pilot50.jsonl --workers 1 --execute
python evaluate.py report results\某次运行\results.jsonl --out REPORT.md
```

使用 `--repeats 3` 做重复试验，使用 `--systems dsh` 单测自己的 DSH 份额。模型运行读取 `DEEPSEEK_API_KEY`，不要把 key 写入题面、报告、仓库或聊天。新机器安装见 `adapters/DSH_SETUP.md` 与 `adapters/GLOSSX_SETUP.md`；源码 checkout 放在本目录旁的 `glossX/`。打包文件排除本机 venv、node_modules 与内部临时状态。

本轮已出现 429 和 402，详情以 RESULTS_ZH.md 为准。后续建议只启动一个 runner、workers=1；脚本现已加入支付错误停止调度保护，但同一时刻已发出的请求仍可能完成。默认 dry run 不会调用模型。25 题 recovery.jsonl 只列题目和材料，不包含新结果。

## 合并到团队实验

把 `inputs.jsonl` 或自建 `tasks.jsonl` 作为任务清单，gold 单独交给评分脚本；只把每条题面和它列出的 papers 交给 agent。其他同学也使用同一模型/材料/超时和输出结构。将新 agent 的答案归一到 `status / answer / usage / metadata` 即可共享评分。上游评测框架的 `GlossXSystem` 调用旧 `/api/agent/runs`，本次没有使用它冒充新 agent loop。GlossX 专属 Route-100 只作路由诊断，不计入 DSH 对比分数。

## 可核实来源

- GlossX 源码：<https://github.com/computersniper/glossX>
- DSH 官方源码：<https://github.com/deepseek-ai/deepseek-harness>
- DSH headless：<https://github.com/deepseek-ai/deepseek-harness/tree/master/packages/app/headless>
- DeepSeek 模型与价格：<https://api-docs.deepseek.com/quick_start/pricing/>
- SciFact：<https://github.com/allenai/scifact>
- QASPER：<https://github.com/allenai/qasper-led-baseline>

实际 token 数来自各系统记录；未返回的值保留为空。未从账户账单核验的费用只能叫估算，不能写成实际扣费。实时价格/别名可能变更，以运行时来源和记录为准。
