"""Share only selected evaluation artifacts, excluding secrets and local runtimes."""
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
TARGET=ROOT.parent/'GlossX_DSH_Evaluation_Bundle.zip'

def include(path):
    rel=path.relative_to(ROOT); parts=rel.parts
    if '__pycache__' in parts:return False
    if len(parts)==1:return path.suffix in {'.py','.md'} or path.name=='.gitignore'
    if parts[0]=='adapters':return len(parts)==2 and path.suffix in {'.py','.mjs','.md'}
    if parts[0] in {'data','final_results'}:return True
    if parts[0]=='public_benchmarks':return 'original_pdfs' not in parts
    if parts[:2]==('vendor','dsh'):
        return len(parts)==3 and path.name in {'package.json','pnpm-lock.yaml','pnpm-workspace.yaml'}
    if parts[0]=='results':
        if len(parts)==3:return path.name in {'plan.json','results.jsonl'}
        if len(parts)==5 and parts[2]=='runs':return path.name in {'request.json','response.json'}
        if len(parts)==6 and parts[2]=='runs' and parts[4]=='response.json.dsh':return path.name in {'events.jsonl','stderr.log'}
    return False

def main():
    files=[]
    # Avoid traversing the large native installation and runtime trees.
    for directory,dirs,names in os.walk(ROOT):
        dirs[:]=[d for d in dirs if d not in {'node_modules','.venv','__pycache__','.tiktoken-cache','.offline-check','original_pdfs'} and not d.startswith('.glossx-state-') and not d.startswith('home-')]
        for name in names:
            p=Path(directory)/name
            if include(p):files.append(p)
    files.sort();secret=os.environ.get('DEEPSEEK_API_KEY','').encode()
    hashes={}
    for p in files:
        data=p.read_bytes()
        if secret and secret in data:raise RuntimeError('Secret detected; refuse to package '+str(p.relative_to(ROOT)))
        hashes[p.relative_to(ROOT).as_posix()]=hashlib.sha256(data).hexdigest()
    with zipfile.ZipFile(TARGET,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,'glossx_dsh_eval/'+p.relative_to(ROOT).as_posix())
        z.writestr('glossx_dsh_eval/BUNDLE_MANIFEST.json',json.dumps({'files_sha256':hashes,'excludes':'local runtimes, native internal state, original arXiv PDFs; sources and download script retained'},indent=2))
    with zipfile.ZipFile(TARGET) as z:
        assert z.testzip() is None
        assert not any('/node_modules/' in p or '/.venv/' in p or '/original_pdfs/' in p for p in z.namelist())
    print(json.dumps({'archive':str(TARGET),'files':len(files)+1,'bytes':TARGET.stat().st_size,'secret_scan':'passed','zip_integrity':'passed'},ensure_ascii=False))

if __name__=='__main__':main()
