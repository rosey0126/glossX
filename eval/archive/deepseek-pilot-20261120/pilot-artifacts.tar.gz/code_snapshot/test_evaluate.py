"""Offline checks of gold isolation, numerical scoring, and failure accounting."""
import json
from pathlib import Path
import tempfile
import unittest
import evaluate as e

class EvaluationTests(unittest.TestCase):
    def setUp(self):
        self.data=e.ROOT/'data'
        self.tasks=e.read_jsonl(self.data/'tasks.jsonl')
        self.gold={g['id']:g for g in e.read_jsonl(self.data/'gold.jsonl')}

    def test_gold_reference_passes_and_wrong_decision_fails(self):
        for t in self.tasks:
            g=self.gold[t['id']]
            obj={'answer':'Evidence-based reference explanation','decision':g['decision'],'numbers':g['numbers'],
                 'citations':[{'claim':'Relevant source evidence','paper':x['paper'],'page':1,'quote':x['text']}
                              for x in g['evidence'] if x['paper'] in g['required_sources']]}
            result={'status':'ok','answer':obj}
            self.assertTrue(e.score_controlled(t,g,result,self.data)['structured_pass'],t['id'])
            result['status']='timeout'
            self.assertFalse(e.score_controlled(t,g,result,self.data)['structured_pass'])
            result['status']='ok'; obj['decision']='WRONG'
            self.assertFalse(e.score_controlled(t,g,result,self.data)['decision_correct'])

    def test_no_gold_staged(self):
        with tempfile.TemporaryDirectory(dir=e.ROOT) as temp:
            work=Path(temp)/'workspace'; e.stage(self.tasks[0],self.data,work)
            self.assertEqual({p.name for p in work.iterdir()},{'source_1.md','source_2.md','source_3.md'})
            self.assertNotIn('gold',e.prompt_for(self.tasks[0]))

    def test_empty_and_nan_never_pass(self):
        t=self.tasks[0]; g=self.gold[t['id']]
        self.assertFalse(e.score_controlled(t,g,{'status':'ok','answer':''},self.data)['structured_pass'])
        obj={'answer':'x','decision':g['decision'],'numbers':{k:float('nan') for k in g['numbers']},'citations':[]}
        self.assertEqual(e.score_controlled(t,g,{'status':'ok','answer':obj},self.data)['numeric_accuracy'],0)

    def test_raw_verdict_and_duplicate_source(self):
        task={'kind':'claim','gold':{'label':'REFUTED'}}
        result={'status':'ok','answer':'Verdict: REFUTED\n{"answer":"Refuted. Opposite direction.","citations":[]}'}
        self.assertTrue(e.score_public(task,result,self.data)['label_correct'])
        task=dict(self.tasks[0]); task['papers']=task['papers']+[task['papers'][0]]
        with tempfile.TemporaryDirectory(dir=e.ROOT) as temp:
            e.stage(task,self.data,Path(temp)/'workspace')

    def test_bad_page_and_header_quotes_do_not_ground(self):
        t=self.tasks[0]; g=self.gold[t['id']]
        obj={'answer':'x','decision':g['decision'],'numbers':g['numbers'],'citations':[
            {'claim':'x','paper':'source_1.md','page':2,'quote':g['evidence'][0]['text']},
            {'claim':'x','paper':'source_2.md','page':1,'quote':'Synthetic evaluation material; not a real publication.'}]}
        scores=e.score_controlled(t,g,{'status':'ok','answer':obj},self.data)
        self.assertEqual(scores['quote_grounding'],0)
        self.assertFalse(scores['structured_pass'])

if __name__=='__main__': unittest.main()
