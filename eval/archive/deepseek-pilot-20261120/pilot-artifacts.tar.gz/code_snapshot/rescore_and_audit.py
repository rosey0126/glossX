"""Postprocess retained answers without new inference or changed task inputs.

Explicitly addresses the 1.1 raw-verdict extraction bug. Never overwrites raw
results. Infrastructure-only retry records may supersede unexecuted records.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import random
import evaluate as e

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('results',nargs='+'); ap.add_argument('--out-dir',default=str(e.ROOT/'final_results'))
    args=ap.parse_args(); out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
    controlled=e.read_jsonl(e.ROOT/'data'/'tasks.jsonl'); public=e.read_jsonl(e.ROOT/'public_benchmarks'/'pilot50.jsonl')
    tasks={t['id']:t for t in controlled+public}; gold={g['id']:g for g in e.read_jsonl(e.ROOT/'data'/'gold.jsonl')}
    selected={}; history=[]
    for src in args.results:
        for r in e.read_jsonl(src):
            key=(r['task'],r['system'],r['repeat'])
            if key in selected:
                previous=selected[key]
                if previous['result'].get('error')!='ambiguous document basename':
                    raise ValueError('Refuse to select among real repeated attempts; only unexecuted duplicate-document staging error may be superseded')
                history.append({'key':key,'reason':'staging failed before model invocation; identical repeated paper reference deduplicated',
                                'superseded_result':previous,'replacement_source':str(src)})
            t=tasks[r['task']]
            base=e.ROOT/('data' if t.get('kind')=='research_audit' else 'public_benchmarks')
            old_scores=r['scores']
            r=dict(r);r['original_scores']=old_scores
            r['scores']=e.score_controlled(t,gold[t['id']],r['result'],base) if t.get('kind')=='research_audit' else e.score_public(t,r['result'],base)
            r['scoring_version']='1.2';r['source_results']=str(Path(src).resolve())
            selected[key]=r
    rows=list(selected.values())
    epath=out/'results.scored.jsonl'
    epath.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
    (out/'infrastructure_history.json').write_text(json.dumps(history,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest={'scoring_version':'1.2','generation_protocol':'1.1','inference_changed':False,
      'reason':'The raw explicit SciFact verdict was dropped when a final JSON answer was present. Extraction now uses both; all systems uniformly rescored.',
      'sources':{str(Path(p).resolve()):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in args.results},
      'scored_sha256':hashlib.sha256(epath.read_bytes()).hexdigest(),'rows':len(rows),'infrastructure_replacements':len(history)}
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    rng=random.Random(20261120)
    by_suite=collections.defaultdict(set)
    for r in rows: by_suite[r['suite']].add(r['task'])
    sample=set()
    for suite,ids in by_suite.items(): sample.update(rng.sample(sorted(ids),max(1,round(len(ids)*.2))))
    sampled=[r for r in rows if r['task'] in sample];rng.shuffle(sampled)
    audit=[];private=[]
    for i,r in enumerate(sampled,1):
        key=f'audit-{i:03d}';t=tasks[r['task']]
        base=e.ROOT/('data' if t.get('kind')=='research_audit' else 'public_benchmarks')
        audit.append({'audit_id':key,'question':t['question'],'response':r['result'].get('answer',''),
          'documents':[{'file':Path(p).name,'text':(base/p).read_text(encoding='utf-8')} for p in dict.fromkeys(t['papers'])],
          'human_correctness':None,'human_citation_support':None,'human_comments':''})
        private.append({'audit_id':key,'task':r['task'],'system':r['system'],'repeat':r['repeat']})
    (out/'human_audit_blind.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in audit),encoding='utf-8')
    (out/'human_audit_key.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in private),encoding='utf-8')
    print(json.dumps({'rows':len(rows),'distinct_tasks':len({r['task'] for r in rows}),'human_audit_responses':len(audit),'infrastructure_replacements':len(history)}))

if __name__=='__main__':main()
