#!/usr/bin/env node
// Thin supervisor for the pinned, official DSH headless CLI.
import { readFile, writeFile, mkdir, mkdtemp, access } from 'node:fs/promises';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';

const HERE = dirname(fileURLToPath(import.meta.url));
const PACKAGE = resolve(HERE, '../vendor/dsh/node_modules/@deepseek-ai/dsh');
const DEFAULT_ENTRY = join(PACKAGE, 'lib/bin.js');

function argument(flag) {
  const i = process.argv.indexOf(flag);
  if (i < 0 || !process.argv[i + 1]) throw new Error(`Required argument: ${flag} PATH`);
  return resolve(process.argv[i + 1]);
}

function scrub(text) {
  const key = process.env.DEEPSEEK_API_KEY;
  return key ? String(text).split(key).join('[REDACTED]') : String(text);
}

function patchFor(request) {
  // JSON string scalars are valid YAML scalars, preserving paths without shell interpolation.
  const rows = [
    { id: 'agent-default-model', config: { provider: 'deepseek-official', model: request.model ?? 'deepseek-flash', reasoningEffort: 'off' } },
    { id: 'llm-deepseek', config: { apiKeyEnv: 'DEEPSEEK_API_KEY', baseURL: 'https://api.deepseek.com/anthropic', thinking: 'disabled', reasoningEffort: 'off', maxTokens: request.max_output_tokens ?? 4096, streamIdleTimeoutMs: 120000 } },
    { id: 'session-log-deepseek', config: { enabled: false } },
    { id: 'tool-fs', config: { read: true, readImage: false, write: false, edit: false, applyPatch: false } },
  ];
  for (const id of [
    'session-title-llm', 'agent-instructions', 'tool-working-directory', 'tool-bash', 'tool-pwsh',
    'tool-jobs', 'tool-web', 'tool-skill', 'skill-filesystem', 'tool-subagent',
    'tool-subagent-fork', 'tool-subagent-control', 'tool-agent-team',
    'tool-workflow', 'tool-goal', 'tool-todo', 'tool-plugin-manager',
  ]) rows.push({ id, disabled: true });
  rows.push({ insert: [{ id: 'evaluation-read-boundary', name: join(HERE, 'dsh_guard.mjs') }] });
  // Cordis accepts its patch list as JSON (a YAML subset), without dependencies.
  return JSON.stringify(rows, null, 2);
}

async function terminate(child) {
  if (child.exitCode !== null) return;
  if (process.platform === 'win32') {
    await new Promise((done) => {
      const killer = spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
      killer.once('error', () => { child.kill(); done(); });
      killer.once('close', done);
    });
  } else {
    child.kill('SIGTERM');
    const escalation = setTimeout(() => child.kill('SIGKILL'), 5000);
    escalation.unref();
  }
}

async function run(request, responsePath) {
  if (!request.prompt || typeof request.prompt !== 'string') throw new Error('request.prompt must be a nonempty string');
  for (const [key, value] of Object.entries({ max_steps: request.max_steps ?? 12, timeout_seconds: request.timeout_seconds ?? 180, max_output_tokens: request.max_output_tokens ?? 4096 })) {
    if (!Number.isFinite(value) || value <= 0 || !Number.isInteger(value)) throw new Error(`${key} must be a positive integer`);
  }
  if (typeof request.workspace !== 'string' || !request.workspace) throw new Error('request.workspace must be a directory path');
  const workspace = resolve(request.workspace);
  await access(workspace);
  const entry = process.env.DSH_CLI_PATH ? resolve(process.env.DSH_CLI_PATH) : DEFAULT_ENTRY;
  await access(entry);
  const version = JSON.parse(await readFile(join(PACKAGE, 'package.json'), 'utf8')).version;
  if (version !== '0.2.2-rc.5' && !process.env.DSH_ALLOW_VERSION_MISMATCH) throw new Error(`DSH version ${version} differs from pinned 0.2.2-rc.5`);
  const logDirectory = `${responsePath}.dsh`;
  await mkdir(logDirectory, { recursive: true });
  const home = await mkdtemp(join(logDirectory, 'home-'));
  const patch = patchFor(request);
  const patchPath = join(home, 'evaluation.patch.yml');
  await writeFile(patchPath, patch, 'utf8');
  const env = { ...process.env, DSH_HOME: home, DSH_TELEMETRY_MODE: 'DISABLED', DSH_TELEMETRY_DISABLED: '1', DSH_PERMISSION_MODE: 'read-only' };
  const args = [entry, 'headless', '--patch', patchPath, '--json', '--permission-mode', 'read-only', '--approval-policy', 'never', '-'];
  const start = Date.now();
  const child = spawn(process.execPath, args, { cwd: workspace, env, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  let stdout = '', stderr = '', buffer = '', stopReason = null, sessionId = null;
  let final = null, stepsStarted = 0, stepsEnded = 0, missingUsage = false;
  const events = [], toolNames = new Set();
  const usage = { input_tokens: 0, output_tokens: 0, cache_read_tokens: 0, cache_write_tokens: 0 };
  const stepLimit = request.max_steps ?? 12;
  const handleLine = (line) => {
    if (!line.trim()) return;
    let event;
    try { event = JSON.parse(line); } catch { return; }
    events.push(event);
    if (event.type === 'session') sessionId = event.sessionId;
    if (event.type === 'final') final = event;
    if (event.type === 'tool_call') toolNames.add(event.tool);
    if (event.type === 'status' && event.phase === 'step_start') {
      stepsStarted++;
      // The native launcher has no max_steps switch. This supervisor stops before
      // accepting another completed step; an in-flight request may already exist.
      if (stepsStarted > stepLimit && !stopReason) {
        stopReason = 'step_limit';
        void terminate(child);
      }
    }
    if (event.type === 'status' && event.phase === 'step_end') {
      stepsEnded++;
      if (!event.usage) missingUsage = true;
      else {
        usage.input_tokens += event.usage.inputTokens ?? 0;
        usage.output_tokens += event.usage.outputTokens ?? 0;
        usage.cache_read_tokens += event.usage.cacheReadTokens ?? 0;
        usage.cache_write_tokens += event.usage.cacheWriteTokens ?? 0;
      }
    }
  };
  child.stdout.on('data', (data) => {
    const text = data.toString('utf8');
    stdout += text;
    buffer += text;
    let newline;
    while ((newline = buffer.indexOf('\n')) !== -1) {
      handleLine(buffer.slice(0, newline));
      buffer = buffer.slice(newline + 1);
    }
  });
  child.stderr.on('data', data => { stderr += data.toString('utf8'); });
  const timer = setTimeout(() => {
    stopReason = 'timeout';
    void terminate(child);
  }, (request.timeout_seconds ?? 180) * 1000);
  child.stdin.end(request.prompt);
  const processResult = await new Promise((done) => {
    child.once('error', error => done({ exitCode: null, error: error.message }));
    child.once('close', (exitCode, signal) => done({ exitCode, signal }));
  });
  clearTimeout(timer);
  if (buffer.trim()) handleLine(buffer);
  const elapsed = (Date.now() - start) / 1000;
  await writeFile(join(logDirectory, 'events.jsonl'), scrub(stdout), 'utf8');
  await writeFile(join(logDirectory, 'stderr.log'), scrub(stderr), 'utf8');
  const completed = !stopReason && processResult.exitCode === 0 && final?.reason?.kind === 'completed';
  return {
    status: completed ? 'ok' : (stopReason ?? 'error'),
    answer: final?.answer ?? final?.text ?? '',
    usage: stepsEnded && !missingUsage ? usage : null,
    metadata: {
      system: 'dsh', implementation: 'official-headless', version,
      requested_model: request.model ?? 'deepseek-flash', actual_model: null,
      actual_model_note: 'Official headless projection does not expose the server-resolved model id.', provider: 'deepseek-official',
      endpoint: 'https://api.deepseek.com/anthropic', thinking: 'disabled',
      temperature: null, temperature_note: 'Native headless CLI has no temperature setting; provider default is not measured.',
      max_output_tokens: request.max_output_tokens ?? 4096,
      max_steps: stepLimit, step_limit_enforcement: 'External supervisor; a request at the limit boundary may be in flight.',
      steps_started: stepsStarted, steps_ended: stepsEnded,
      usage_complete: stepsEnded > 0 && !missingUsage && completed,
      input_token_accounting: 'input_tokens excludes cache_read_tokens and cache_write_tokens; these are disjoint provider buckets.',
      elapsed_seconds: elapsed, process: processResult,
      session_id: sessionId, terminal_reason: final?.reason ?? null,
      tools_called: [...toolNames], tools_allowed: ['read', 'glob', 'grep'],
      policy: 'local-document-read-only', workspace, dsh_home: home,
      log_directory: logDirectory, session_log_upload: false, telemetry_upload: false,
      patch_sha256: createHash('sha256').update(patch).digest('hex'),
      error: completed ? null : scrub(processResult.error ?? events.find(e => e.type === 'error')?.message ?? stderr.slice(-4000)),
    },
  };
}

let responsePath;
try {
  const requestPath = argument('--request');
  responsePath = argument('--response');
  await mkdir(dirname(responsePath), { recursive: true });
  const request = JSON.parse((await readFile(requestPath, 'utf8')).replace(/^\uFEFF/, ''));
  const result = await run(request, responsePath);
  await writeFile(responsePath, JSON.stringify(result, null, 2), 'utf8');
  console.log(JSON.stringify({ status: result.status, response: responsePath, elapsed_seconds: result.metadata.elapsed_seconds }));
  if (result.status !== 'ok') process.exitCode = 1;
} catch (error) {
  const result = { status: 'error', answer: '', usage: null, metadata: { system: 'dsh', error: scrub(error.message) } };
  if (responsePath) await writeFile(responsePath, JSON.stringify(result, null, 2), 'utf8');
  console.error(scrub(error.message));
  process.exitCode = 1;
}
