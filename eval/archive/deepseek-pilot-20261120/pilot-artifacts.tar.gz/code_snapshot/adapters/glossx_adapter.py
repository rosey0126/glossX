"""Run the checked-out GlossX native harness in an isolated benchmark profile.

No agent loop or file tool is reimplemented here. The loop, system prompt,
native function-call provider, permissions, result wrapping, and file tools
come from GlossX. This profile exposes only workspace reading tools.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid


ALLOWED_TOOLS = ("fs_list", "fs_read", "fs_glob", "fs_grep", "result_read")


def redact(text: str) -> str:
    key = os.environ.get("DEEPSEEK_API_KEY", "")
    return text.replace(key, "[REDACTED]") if key else text


def git_revision(repo: Path) -> str | None:
    try:
        return subprocess.check_output(
            ["git", "-C", str(repo), "rev-parse", "HEAD"],
            text=True, timeout=10, stderr=subprocess.DEVNULL,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return None


def install_parameter_shim(settings: dict, observed: list[dict]) -> None:
    """Inject only model parameters missing from GlossX's compatible provider.

    The original provider still creates/parses the request/stream. This shim
    records the effective non-secret wire parameters for reproducibility.
    """
    import httpx

    native_init = httpx.AsyncClient.__init__

    async def inject(request: httpx.Request) -> None:
        if not request.url.path.rstrip("/").endswith("/chat/completions"):
            return
        body = json.loads(request.content)
        body.update(settings)
        raw = json.dumps(body, ensure_ascii=False).encode("utf-8")
        # httpx has no public setter for request content inside an event hook.
        # Replace both its cached bytes and stream before the native send.
        request._content = raw
        request.stream = httpx.ByteStream(raw)
        request.headers["Content-Length"] = str(len(raw))
        record = {"model": body.get("model"), **settings,
                  "served_model": None, "finish_reasons": []}
        observed.append(record)
        request.extensions["benchmark_observation"] = record

    class ObservedStream(httpx.AsyncByteStream):
        def __init__(self, native_stream, record):
            self.native_stream = native_stream
            self.record = record
            self.pending = b""

        def observe_line(self, line: bytes) -> None:
            if not line.startswith(b"data:"):
                return
            try:
                event = json.loads(line[5:].strip())
            except (ValueError, UnicodeError):
                return
            if not isinstance(event, dict):
                return
            if event.get("model"):
                self.record["served_model"] = event["model"]
            for choice in event.get("choices") or []:
                reason = choice.get("finish_reason")
                if reason is not None and reason not in self.record["finish_reasons"]:
                    self.record["finish_reasons"].append(reason)

        async def __aiter__(self):
            async for chunk in self.native_stream:
                self.pending += chunk
                while b"\n" in self.pending:
                    line, self.pending = self.pending.split(b"\n", 1)
                    self.observe_line(line.rstrip(b"\r"))
                # Preserve every byte and its ordering for the native provider.
                yield chunk
            if self.pending:
                self.observe_line(self.pending)

        async def aclose(self):
            await self.native_stream.aclose()

    async def observe(response: httpx.Response) -> None:
        record = response.request.extensions.get("benchmark_observation")
        if record is not None:
            record["http_status"] = response.status_code
            response.stream = ObservedStream(response.stream, record)

    def isolated_init(self, *args, **kwargs):
        hooks = dict(kwargs.get("event_hooks") or {})
        hooks["request"] = [*hooks.get("request", []), inject]
        hooks["response"] = [*hooks.get("response", []), observe]
        kwargs["event_hooks"] = hooks
        native_init(self, *args, **kwargs)

    httpx.AsyncClient.__init__ = isolated_init


async def run(request: dict, response_path: Path, *, mock: bool = False) -> dict:
    started = time.monotonic()
    package_root = Path(__file__).resolve().parents[1]
    repo = Path(request.get("glossx_repo") or package_root.parent / "glossX").resolve()
    backend = repo / "backend"
    if not (backend / "app" / "harness" / "engine.py").is_file():
        raise ValueError("GlossX checkout not found; set request.glossx_repo")
    workspace_path = Path(request["workspace"]).resolve(strict=True)
    if not workspace_path.is_dir():
        raise ValueError("request.workspace must be an existing directory")
    prompt = str(request["prompt"])
    model = str(request.get("model") or "deepseek-flash")
    timeout = float(request.get("timeout_seconds", 180))
    max_steps = int(request.get("max_steps", 12))
    if not 1 <= max_steps <= 200 or not 1 <= timeout <= 3600:
        raise ValueError("invalid max_steps or timeout_seconds")
    if not mock and not os.environ.get("DEEPSEEK_API_KEY"):
        raise ValueError("DEEPSEEK_API_KEY is not set")

    # State is next to the response, outside the model-visible workspace.
    # Every process/task gets a new library/home, with no personal settings.
    state = response_path.parent / (".glossx-state-" + uuid.uuid4().hex[:12])
    state.mkdir(parents=True, exist_ok=False)
    if state == workspace_path or workspace_path in state.parents:
        raise ValueError("response must be outside the model-visible workspace")
    os.environ.update(
        GLOSS_DATA_DIR=str(state / "data"),
        GLOSS_CACHE_DIR=str(state / "cache"),
        GLOSSX_HOME=str(state / "home"),
        TIKTOKEN_CACHE_DIR=str(package_root / ".tiktoken-cache"),
    )
    sys.path.insert(0, str(backend))
    from app import config
    from app.agent import projects
    from app.agent.capabilities import CapabilityRegistry
    from app.harness import context, engine, settings
    from app.harness.builtin_tools import harness_capabilities
    from app.harness.manager import SessionManager
    from app.harness.session import Runtime, new_id, new_session, now
    from app.library import store

    # Never serialize the API key to config.json or put it in a model workspace.
    config.DEFAULT_CONFIG["provider"] = "openai"
    config.DEFAULT_CONFIG["output_language"] = "English"
    config.DEFAULT_CONFIG["providers"]["openai"].update(
        model=model,
        base_url=str(request.get("base_url") or "https://api.deepseek.com"),
        api_key=os.environ.get("DEEPSEEK_API_KEY", ""),
        timeout=timeout,
    )
    profile = settings.normalize({
        "default_mode": "ask", "max_tool_rounds": max_steps,
        "context_limit": 120_000, "vcs": {"auto_commit": False},
    })
    config.GLOSSX_HOME.mkdir(parents=True, exist_ok=True)
    config.HARNESS_SETTINGS_PATH.write_text(json.dumps(profile), encoding="utf-8")
    store.init_db()

    # Use the original native capability definitions/handlers. The benchmark
    # profile excludes network, shell, external delegates, nested agents,
    # library workflows, and writes rather than relying on prompt obedience.
    registry = CapabilityRegistry()
    for cap in harness_capabilities():
        if cap.meta.get("tool") in ALLOWED_TOOLS:
            registry.register(cap)

    async def benchmark_registry(_settings=None):
        return registry

    engine.harness_registry = benchmark_registry
    wire_settings = {
        "max_tokens": int(request.get("max_output_tokens", 4096)),
        "thinking": {"type": "disabled"},
    }
    if request.get("temperature") is not None:
        wire_settings["temperature"] = float(request["temperature"])
    observed: list[dict] = []
    install_parameter_shim(wire_settings, observed)

    project = projects.create("Research evaluation", folder=workspace_path)
    manager = SessionManager()
    session = new_session(
        title="Research evaluation", project_id=project["id"], mode="ask",
        provider="openai", model=model, context_limit=120_000,
    )
    rt = Runtime(session, manager)
    manager.register_child(rt)
    engine.add_message(rt, context.stamp({
        "id": new_id("m_"), "type": "user", "text": prompt,
        "attachments": [], "created_at": now(),
    }))
    rt.running = True
    rt.refresh_status()

    if mock:
        # A separate explicitly marked offline integration check. It tests the
        # real parser, loop, fs_read, sandbox, result wrapping and final text.
        from app.providers import registry as providers

        calls = 0

        async def fake_stream(*args, **kwargs):
            nonlocal calls
            calls += 1
            if calls == 1:
                yield '<tool_call>{"name":"fs_read","arguments":{"path":"probe.md"}}</tool_call>'
            elif calls == 2:
                yield '<tool_call>{"name":"fs_read","arguments":{"path":"../secret-gold.json"}}</tool_call>'
            else:
                yield '{"answer":"OFFLINE_ADAPTER_CHECK","decision":"TEST","numbers":{},"citations":[]}'

        providers.stream = fake_stream

    info = await asyncio.wait_for(engine.run_turn(rt, max_rounds=max_steps), timeout)
    engine.finish_turn(rt, info)
    messages = session["messages"]
    answer = next((str(m.get("text") or "") for m in reversed(messages)
                   if m.get("type") == "assistant"), "")
    tools = [m for m in messages if m.get("type") == "tool_call"]
    status = str(info.get("stop_reason") or "error")
    if status == "completed":
        status = "ok"
    if info.get("cancelled"):
        status = "timeout"
    usage = dict(session["usage"])
    usage["tool_calls"] = len(tools)
    metadata = {
        "system": "glossx", "entrypoint": "app.harness.engine.run_turn",
        "repository_commit": git_revision(repo), "model": model,
        "profile": "workspace-read-only", "tools": list(ALLOWED_TOOLS),
        "library_workflow_enabled": False, "external_tools_enabled": False,
        "max_tool_rounds": max_steps, "timeout_seconds": timeout,
        "wire_settings": wire_settings, "parameter_shim": "httpx-request-hook",
        "observed_requests": observed, "state_directory": str(state),
        "session_id": session["id"], "stop_reason": info.get("stop_reason"),
        "offline_mock": mock, "duration_seconds": round(time.monotonic() - started, 3),
    }
    if mock:
        metadata["offline_checks"] = {
            "native_fs_read_executed": bool(tools and tools[0].get("status") == "done"),
            "parent_path_read_rejected": bool(len(tools) > 1 and tools[1].get("status") == "error"),
        }
    return {
        "status": status, "answer": answer, "usage": usage,
        "metadata": metadata, "error": info.get("error"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--response", type=Path, required=True)
    parser.add_argument("--offline-self-test", action="store_true")
    args = parser.parse_args()
    response_path = args.response.resolve()
    response_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        request = json.loads(args.request.read_text(encoding="utf-8-sig"))
        result = asyncio.run(run(request, response_path, mock=args.offline_self_test))
    except Exception as error:
        result = {"status": "error", "answer": "", "usage": {},
                  "metadata": {"system": "glossx", "offline_mock": args.offline_self_test},
                  "error": redact(f"{type(error).__name__}: {error}")}
    response_path.write_text(redact(json.dumps(result, ensure_ascii=False, indent=2)), encoding="utf-8")
    print(json.dumps({"status": result["status"], "response": str(response_path)}, ensure_ascii=False))
    return 0 if result["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
