# DSH 本地科研任务评测接入

这里运行的是官方 `@deepseek-ai/dsh@0.2.2-rc.5` 的 `headless` profile，未重写 agent loop、模型 provider 或文件工具。此版本已在当前 Windows 环境安装并验证真实启动。Node 要求 `>=24.9.0`，本机测试版本为 `v24.22.1`。

## 安装

运行目录为 `glossx_dsh_eval`；需要 Node.js 和 pnpm。固定版本及完整依赖锁定在 `vendor/dsh/package.json`、`vendor/dsh/pnpm-lock.yaml`。复现安装：

```powershell
pnpm --dir vendor/dsh install --frozen-lockfile
```

`pnpm-workspace.yaml` 只允许 DSH 的进程组件、`node-pty` 和 `koffi` 运行必要安装脚本。未启用 Google GenAI、protobufjs 的安装脚本，这些组件不参与本评测路径。

API key 通过进程环境变量 `DEEPSEEK_API_KEY` 继承，不能写入请求 JSON 或提交到仓库。适配器不会显示 key，并在输出日志中替换此 key 的字面值。

## 接口

```powershell
node adapters/dsh_adapter.mjs --request request.json --response response.json
```

请求：

```json
{
  "prompt": "Read the supplied local materials and return the required JSON answer.",
  "workspace": "[LOCAL_ABSOLUTE_PATH]/absolute/path/to/fresh/task-workspace",
  "model": "deepseek-flash",
  "max_steps": 12,
  "max_output_tokens": 4096,
  "timeout_seconds": 180
}
```

结果包含 `status`（`ok`、`error`、`timeout`、`step_limit`）、`answer`（原生最终文本）、`usage`（token 消耗）和 `metadata`。进程退出码与原生终止原因同时成功才记 `ok`。空文本、API 错误、超时均保留原始失败记录。

每次使用新的 `DSH_HOME` 和新的原生 Session，放在 `response.json.dsh/home-*`。`events.jsonl` 保存原生 headless NDJSON；`stderr.log` 保存诊断。不要把这些运行目录复制进另一个任务的输入 workspace。

## 受控评测配置与边界

- 官方 `deepseek-official` 路由，固定 `https://api.deepseek.com/anthropic`，`thinking: disabled`，`reasoningEffort: off`，每请求最多输出 4096 tokens。
- 原生 headless 未暴露 temperature 参数，metadata 记录 `null`；不声称温度严格一致。服务端实际型号未通过 headless 投影暴露，`actual_model` 为 `null`，保留请求的型号别名。
- 原生没有 `max_steps` 命令选项。外部监督器统计 `step_start` 并在超限时终止进程树；触发边界处一个请求可能已在途。超时为独立墙钟上限，包含 DSH 启动时间。
- 本轮为本地文档、只读受控配置：只向模型保留原生 `read`、`glob`、`grep` 文件工具；停用 shell、web、插件管理、子 agent、任务计划工具和额外 session-title 模型调用。此配置结果不能直接称作 DSH 默认全工具配置的结果。
- `dsh_guard.mjs` 通过官方 `ctx.tools.guard()` seam 检查真实路径，只允许当前任务 workspace 内的读取和搜索。上级目录、其他运行、答案键被拒绝。没有替换工具或 provider 实现。输入文件不应含指向 workspace 外的符号链接；普通文件路径及带符号链接的显式目标由真实路径检查约束。
- 禁用父级 `AGENTS.md` 自动加载与 filesystem skills 自动发现。输入 prompt 仍应清楚规定只读所给资料和输出格式。
- 已禁用原生 session-log contribution 和 OTel telemetry；任务内容仍会作为模型输入提交给 DeepSeek API。

`usage.input_tokens` 是原生未缓存输入计数，缓存读写为独立字段。比较总输入时相加：`input_tokens + cache_read_tokens + cache_write_tokens`；输出只取 `output_tokens`。当缺少用量样本时返回 `null`，不能将其当成 0。

## 已完成的无收费验证

1. `--version` 返回 `0.2.2-rc.5`，`headless --help` 与官方支持选项一致。
2. 固定 lockfile 安装成功，Windows 原生进程依赖的安装脚本完成。
3. 在临时没有 API key 的子进程中真实启动本适配器：原生 loop 创建 Session 并返回 `MISSING_CREDENTIAL`。这验证启动和配置链，不是模型性能结果。

## 官方依据

- [官方源码与安装入口](https://github.com/deepseek-ai/deepseek-harness)
- [headless 输入、JSON 事件和退出协议](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/bundle/headless/README.md)
- [原生 DeepSeek provider 配置](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/llm/llm-deepseek/README.md)
- [工具 guard seam](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/tools/tools/src/index.ts)

官方 master 会变化；本次执行以 npm 固定版本、lockfile、每次运行的 patch SHA256 和原始日志为准。
