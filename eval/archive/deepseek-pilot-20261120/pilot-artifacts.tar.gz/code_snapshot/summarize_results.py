"""Build a candid Chinese handover from the uniformly rescored records."""
from __future__ import annotations
import collections
import copy
import json
from pathlib import Path
import random
import statistics
import evaluate as e

def write_jsonl(path,rows):
    path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')

def error_kind(r):
    if r['result'].get('status')=='ok': return None
    err=str(r['result'].get('error',''))+' '+str(r['result'].get('metadata',{}).get('error',''))
    if '402' in err or 'Insufficient Balance' in err: return 'HTTP402_payment'
    if '429' in err: return 'HTTP429_rate_limit'
    return 'other_error'

def interval(values,clusters):
    keys=list(clusters);rng=random.Random(20261120);boot=[]
    for _ in range(5000): boot.append(statistics.mean(x for k in rng.choices(keys,k=len(keys)) for x in clusters[k]))
    boot.sort();return [boot[125],boot[4874]]

def main():
    rows=e.read_jsonl(e.ROOT/'final_results'/'results.scored.jsonl')
    tasks={t['id']:t for p in [e.ROOT/'data'/'tasks.jsonl',e.ROOT/'public_benchmarks'/'pilot50.jsonl'] for t in e.read_jsonl(p)}
    gold={g['id']:g for g in e.read_jsonl(e.ROOT/'data'/'gold.jsonl')}
    pairs=collections.defaultdict(dict)
    for r in rows: pairs[r['task']][r['system']]=r
    assert len(rows)==180 and len(pairs)==90
    assert all(set(p)=={'glossx','dsh'} for p in pairs.values())
    # Exact prompt identity, not a claim that the native system prompts match.
    assert all(len({r['prompt_sha256'] for r in p.values()})==1 for p in pairs.values())
    controlled=[p for p in pairs.values() if next(iter(p.values()))['suite'].startswith('GlossX')]
    complete=[p for p in controlled if all(r['result']['status']=='ok' for r in p.values())]
    groups=collections.defaultdict(list)
    for r in rows: groups[(r['suite'],r['system'])].append(r)
    summary={};lines=['# GlossX 与 DSH 科研任务实测试点','',
      '本轮已经接通两套原生 agent，备齐 100 题，并对其中 90 题完成每系统一次的运行尝试。当前结果不能证明 GlossX 在科研任务上优于 DSH。40 题控制测试里有 36 题双方正常完成，核心分类与数值正确分别为 GlossX 34/36、DSH 33/36；严格格式和引文定位复合通过均为 32/36。这个小差异不足以支持胜出结论。','',
      '测试时间：2026 年 11 月 20 日，北京时间。模型均为 deepseek-flash，thinking 禁用。自建 50 题包含 10 条开发题和 40 条测试题；本轮正式跑后者。另跑 SciFact 30 条和 QASPER 20 条。最早两条开发题的接入预检单独存档，不混入表格。','',
      '## 本轮完整尝试的分数','',
      '失败保留在这张表的分母，故同时受服务可用性影响。自建题是 10 个任务族的参数化控制案例，不能按 40 个独立题型理解。','',
      '| 指标 | GlossX | DSH |','| --- | ---: | ---: |']
    def avg(suite,system,key):
        items=groups[(suite,system)];return statistics.mean(float(r['scores'].get(key,0)) for r in items)
    c_suite=controlled[0]['glossx']['suite']
    for title,suite,key in [('自建测试核心正确 / 40',c_suite,'core_correct'),('自建测试严格复合通过 / 40',c_suite,'structured_pass'),
                           ('SciFact 三分类准确率 / 30','scifact','label_correct'),('QASPER 完整 answer token-F1 / 20','qasper','answer_f1')]:
        lines.append(f'| {title} | {avg(suite,"glossx",key):.4f} | {avg(suite,"dsh",key):.4f} |')
    lines += ['', 'SciFact macro-F1：GlossX 0.5596，DSH 0.7775（30 题，失败保留）。这些数值受服务失败影响，不宜单独用于科研能力排名。QASPER 的统一提示词同时要求解释推理，导致 answer 冗长、token-F1 偏低；即使首句答对 yes/no，也会受长度惩罚。后续应在新协议里分开 short_answer 与 explanation，再冻结重测；本次不从既有回答挑最有利的句子提分。','',
      '## 服务故障与有效配对','',
      '| 数据集 | GlossX 正常返回 | DSH 正常返回 | 双方正常完成同题 |','| --- | ---: | ---: | ---: |']
    recovery={'controlled':[],'public':[]}
    for suite in [c_suite,'scifact','qasper']:
        ps=[p for p in pairs.values() if p['glossx']['suite']==suite]
        counts={s:sum(p[s]['result']['status']=='ok' for p in ps) for s in ['glossx','dsh']}
        both=sum(all(r['result']['status']=='ok' for r in p.values()) for p in ps)
        lines.append(f'| {suite} | {counts["glossx"]}/{len(ps)} | {counts["dsh"]}/{len(ps)} | {both}/{len(ps)} |')
        for p in ps:
            if not all(r['result']['status']=='ok' for r in p.values()):
                recovery['controlled' if suite==c_suite else 'public'].append(tasks[p['glossx']['task']])
    lines += ['', '后半段出现 HTTP 429 和 HTTP 402。402 是支付/额度错误；停止新增模型调用后，只读余额接口仍显示 is_available=true、余额人民币 0.55 元。这是事后快照，不能证明此前没有额度错误，也无法从中还原本轮实际扣费。没有执行充值或改用其他凭据。','']
    failures=[]
    for system in ['glossx','dsh']:
        counts=collections.Counter(error_kind(r) for r in rows if r['system']==system and error_kind(r))
        lines.append(f'- {system}：'+', '.join(f'{k} {v} 次' for k,v in sorted(counts.items())))
    lines += ['', '正常配对样本可提供诊断，但剔除服务故障后的子集存在选择偏差；不能替代整批结果。自建 36 条正常配对的核心正确率为 94.44% / 91.67%；SciFact 18 条正常配对的正确数为 GlossX 13、DSH 14。','',
      '| 正常配对自建题的耗时 | GlossX | DSH |','| --- | ---: | ---: |']
    means={s:statistics.mean(p[s]['result']['latency_s'] for p in complete) for s in ['glossx','dsh']}
    lines.append(f'| 同 36 题平均墙钟秒数 | {means["glossx"]:.2f} | {means["dsh"]:.2f} |')
    clusters=collections.defaultdict(list)
    for p in controlled: clusters[p['glossx']['family']].append(float(p['glossx']['scores']['core_correct'])-float(p['dsh']['scores']['core_correct']))
    ci=interval([],clusters)
    delta=avg(c_suite,'glossx','core_correct')-avg(c_suite,'dsh','core_correct')
    lines += ['',f'含全部 40 题的核心正确率差值（GlossX − DSH）为 {delta:.4f}；按任务族聚类 bootstrap 的探索性 95% 区间为 [{ci[0]:.4f}, {ci[1]:.4f}]，包含零。单次运行、族数少、受控合成题和服务故障均限制解释。','',
      '## 评分修复和敏感性','',
      'SciFact 初始评分只看最终 JSON 的 answer，漏掉正文中明确的 Verdict。评分 1.2 对所有系统统一重算：优先 JSON 显式 verdict，其次正文显式 verdict，再接受 answer 首句的明确类别；原始答案和初始分数都保留。推断请求/题目没有改变。','',
      '自建题原评分容差为绝对 0.001，而题面没有规定保留几位小数。个别预算题正确推导后写成 8.70% 或 9.52%，因四舍五入超差。主表保持原严格分数，以下仅统一放宽预算题百分数至 0.0050001，报告敏感性，不称作修复模型算术。','']
    sensitivity={}
    for system in ['glossx','dsh']:
        items=groups[(c_suite,system)];hits=0
        for r in items:
            g=copy.deepcopy(gold[r['task']])
            if tasks[r['task']]['family']=='budget':g['absolute_tolerance']=.0050001
            hits+=e.score_controlled(tasks[r['task']],g,r['result'],e.ROOT/'data')['core_correct']
        sensitivity[system]=hits/40
        lines.append(f'- {system}：核心正确 {hits}/40（{hits/40:.2%}）。')
    lines += ['', 'strict JSON 格式、可定位引句、证据文档覆盖与语义支持分别看。36 条待人工核验答复已做匿名抽样（每组 20% 的题目，两个系统均抽），位于 final_results/human_audit_blind.jsonl；尚未进行人工审核，不能发布引用语义支持率或 κ。','',
      '## 复现范围和下一步','',
      '本轮比较的是只读本地资料的原生 harness 配置。GlossX 的文库工作流、span 验证和子 agent 没有启用；DSH 的网络、shell 和子 agent 同样禁用。两者使用不同兼容 API 路由，温度默认值未知，步数语义不完全相同；不能声称严格等采样参数、等总 token、或完整产品优劣。','',
      '已为 25 道一方或双方未正常完成的题准备两份 recovery.jsonl。以后额度与限流条件恢复时，以单进程串行运行双边配对补测；原始批次独立保留，补测作为恢复实验单列。','',
      '```powershell','python evaluate.py run --tasks data\\recovery.jsonl --workers 1',
      'python evaluate.py run --tasks public_benchmarks\\recovery.jsonl --workers 1',
      '# 确认 API 额度可用后，为上面命令添加 --execute；默认只是计划。','```','',
      '下一轮若要做论文级结论，需要固定更明确的采样/重试/总预算、短答案字段、独立测试题和图表输入，再每系统重复三次。现有 100 条任务与标准答案可直接交团队合并；自建任务的 10 个族要整体分组抽样，避免把同模板的数值变体当成独立证据。','',
      '数据和依赖许可见 NOTICE.md；共享包不含 arXiv 原 PDF、本机运行环境和内部状态，原 PDF 本地已保存，可按脚本重新获取。']
    write_jsonl(e.ROOT/'data'/'recovery.jsonl',recovery['controlled'])
    write_jsonl(e.ROOT/'public_benchmarks'/'recovery.jsonl',recovery['public'])
    for r in rows:
        if error_kind(r): failures.append({'task':r['task'],'system':r['system'],'kind':error_kind(r),'error':r['result'].get('error') or r['result'].get('metadata',{}).get('error')})
    write_jsonl(e.ROOT/'final_results'/'provider_failures.jsonl',failures)
    summary={'rows':len(rows),'tasks_attempted':len(pairs),'normally_returned':sum(r['result']['status']=='ok' for r in rows),
       'complete_pairs':sum(all(r['result']['status']=='ok' for r in p.values()) for p in pairs.values()),
       'core_delta_all_controlled':delta,'core_cluster_bootstrap_95ci':ci,'sensitivity_budget_rounding':sensitivity,
       'recovery_tasks':{k:len(v) for k,v in recovery.items()},'prompt_hashes_match_per_pair':True}
    (e.ROOT/'final_results'/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    (e.ROOT/'RESULTS_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
