"""Prepare a frozen public pilot: SciFact-dev 30 + QASPER-dev 20.

Inspired by computersniper/glossX eval/glossx_eval/prepare.py and tasks.py.
This independent stdlib implementation keeps failed PDF downloads in the
selection, retains individual QASPER annotations, and never calls a model.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import random
import shutil
import ssl
import subprocess
import tarfile
import time
import urllib.request


SEED = 20261120
SOURCES = {
    "scifact": {
        "url": "https://scifact.s3-us-west-2.amazonaws.com/release/latest/data.tar.gz",
        "file": "scifact-data.tar.gz",
        "sha256": "11c621288d41ac144d29b13b0f8503b3820b7d6e8b1f6ff24dff335c196d76be",
        "documentation": "https://github.com/allenai/scifact",
    },
    "qasper": {
        "url": "https://qasper-dataset.s3.us-west-2.amazonaws.com/qasper-train-dev-v0.3.tgz",
        "file": "qasper-train-dev-v0.3.tgz",
        "sha256": "a28fdf966db827bcee3d873107d6b6669864fb7ca8fbf73a192f5e39191bdb5a",
        "documentation": "https://github.com/allenai/qasper-led-baseline",
    },
}
USER_AGENT = "glossx-dsh-eval/0.1 (public research benchmark preparation)"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")


def fetch(url: str, timeout: float = 120) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.read()
    except urllib.error.URLError as error:
        # Native Windows curl uses the Windows trust store. Keep TLS verification
        # enabled when Python's separately packaged CA store lacks a root.
        native_curl = shutil.which("curl.exe")
        if not isinstance(error.reason, ssl.SSLCertVerificationError) or not native_curl:
            raise
        result = subprocess.run([native_curl, "--fail", "--silent", "--show-error", "--location",
                                 "--max-time", str(timeout), "--user-agent", USER_AGENT, url],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=timeout + 5, check=False)
        if result.returncode:
            raise RuntimeError(result.stderr.decode("utf-8", errors="replace").strip()) from error
        return result.stdout


def raw_release(out: Path, suite: str) -> bytes:
    source = SOURCES[suite]
    path = out / "raw" / source["file"]
    if not path.exists():
        data = fetch(source["url"])
        if sha256(data) != source["sha256"]:
            raise ValueError(f"{suite}: release changed; review new SHA before resampling")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    blob = path.read_bytes()
    if sha256(blob) != source["sha256"]:
        raise ValueError(f"{path}: unexpected SHA256")
    return blob


def tar_member(blob: bytes, filename: str) -> bytes:
    # Read a named file only; never extract untrusted archive paths to disk.
    with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as archive:
        matches = [m for m in archive.getmembers()
                   if m.isfile() and m.name.rsplit("/", 1)[-1] == filename]
        if len(matches) != 1:
            raise ValueError(f"Expected one {filename}; found {len(matches)}")
        stream = archive.extractfile(matches[0])
        assert stream is not None
        return stream.read()


def lines(blob: bytes) -> list[dict]:
    return [json.loads(line) for line in blob.decode("utf-8").splitlines() if line.strip()]


def select(rows: list[dict], n: int) -> list[dict]:
    ordered = sorted(rows, key=lambda row: row["id"])
    if len(ordered) < n:
        raise ValueError(f"Need {n} records, have {len(ordered)}")
    return sorted(random.Random(SEED).sample(ordered, n), key=lambda row: row["id"])


def qasper_reference(annotation: dict) -> dict | None:
    """Follow the official evaluator's priority and comma-join convention.

    Each annotation is one alternative reference. Never combine answers or
    evidence across annotators into a synthetic answer/reference.
    """
    answer = annotation.get("answer", {})
    if answer.get("unanswerable") is True:
        text, kind, evidence = "Unanswerable", "none", []
    elif answer.get("extractive_spans"):
        text, kind = ", ".join(answer["extractive_spans"]), "extractive"
        evidence = answer.get("evidence", [])
    elif answer.get("free_form_answer"):
        text, kind = answer["free_form_answer"], "abstractive"
        evidence = answer.get("evidence", [])
    elif answer.get("yes_no") is not None:
        text, kind = "Yes" if answer["yes_no"] else "No", "boolean"
        evidence = answer.get("evidence", [])
    else:
        return None
    return {"annotation_id": annotation.get("annotation_id"), "answer": text,
            "type": kind, "evidence": evidence,
            "text_evidence": [e for e in evidence if "FLOAT SELECTED" not in e]}


def build_scifact(out: Path, blob: bytes) -> tuple[list[dict], dict]:
    claims = lines(tar_member(blob, "claims_dev.jsonl"))
    corpus = {str(row["doc_id"]): row for row in lines(tar_member(blob, "corpus.jsonl"))}
    eligible, excluded = [], []
    for row in claims:
        label_set = {e["label"] for values in row.get("evidence", {}).values() for e in values}
        labels = {frozenset({"SUPPORT"}): "SUPPORTED", frozenset({"CONTRADICT"}): "REFUTED",
                  frozenset(): "NOT ENOUGH EVIDENCE"}
        label = labels.get(frozenset(label_set))
        docs = [str(doc) for doc in row.get("cited_doc_ids", [])]
        if label is None or not docs or any(doc not in corpus for doc in docs):
            excluded.append({"claim_id": row["id"], "reason": "mixed label or missing cited document"})
            continue
        if set(row.get("evidence", {})) - set(docs):
            raise ValueError(f"Evidence outside cited documents in claim {row['id']}")
        eligible.append({"id": f"scifact-{row['id']}", "suite": "scifact", "kind": "claim",
                         "question": row["claim"],
                         "papers": [f"documents/scifact/{doc}.md" for doc in docs],
                         "gold": {"label": label, "evidence": row.get("evidence", {}),
                                  "claim_id": row["id"], "cited_doc_ids": row["cited_doc_ids"],
                                  "titles": {doc: corpus[doc]["title"] for doc in docs},
                                  "protocol": "closed-document cited-abstract classification"}})
    tasks = select(eligible, 30)
    for doc in sorted({str(d) for task in tasks for d in task["gold"]["cited_doc_ids"]}):
        row = corpus[doc]
        path = out / "documents" / "scifact" / f"{doc}.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        text = (f"# {row['title']}\n\nSciFact corpus doc_id: {doc}\n\n"
                "Format: released abstract text, not an original paper PDF. Sentence indices are zero-based.\n\n")
        text += "\n\n".join(f"[{i}] {s}" for i, s in enumerate(row["abstract"])) + "\n"
        path.write_text(text, encoding="utf-8")
    return tasks, {"split": "dev", "population": len(claims), "eligible": len(eligible),
                   "excluded": excluded, "selection": [task["id"] for task in tasks],
                   "label_counts": dict(Counter(task["gold"]["label"] for task in tasks))}


def build_qasper(out: Path, blob: bytes) -> tuple[list[dict], dict]:
    data = json.loads(tar_member(blob, "qasper-dev-v0.3.json"))
    eligible, invalid = [], []
    for paper_id, paper in data.items():
        for qa in paper["qas"]:
            references = []
            for annotation in qa["answers"]:
                ref = qasper_reference(annotation)
                if ref is not None:
                    references.append(ref)
                else:
                    invalid.append(annotation.get("annotation_id"))
            if not references:
                continue
            eligible.append({"id": f"qasper-{qa['question_id']}", "suite": "qasper", "kind": "qa",
                             "question": qa["question"], "papers": [f"documents/qasper/{paper_id}.md"],
                             "gold": {"answers": [ref["answer"] for ref in references],
                                      "references": references, "annotations": qa["answers"],
                                      "question_id": qa["question_id"], "arxiv_id": paper_id,
                                      "title": paper["title"],
                                      "protocol": "released-text closed-document QA; full annotator references"}})
    tasks = select(eligible, 20)
    paper_ids = sorted({task["gold"]["arxiv_id"] for task in tasks})
    for paper_id in paper_ids:
        paper = data[paper_id]
        path = out / "documents" / "qasper" / f"{paper_id}.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        parts = [f"# {paper['title']}", f"QASPER release arXiv ID: {paper_id}",
                 "Format: QASPER v0.3 released S2ORC text, not an original PDF. "
                 "Paragraph IDs below are sidecar locators, not PDF pages. "
                 "Bibliography and float placeholders are preserved as released. "
                 "Figure/table captions are included; their image contents are not present in this Markdown.",
                 "## Abstract", f"[abstract] {paper.get('abstract', '')}"]
        for si, section in enumerate(paper.get("full_text", [])):
            parts.append(f"## {section.get('section_name', '') or 'Untitled section'}")
            parts.extend(f"[s{si}-p{pi}] {paragraph}"
                         for pi, paragraph in enumerate(section.get("paragraphs", [])))
        parts.append("## Released figure and table captions")
        for fi, figure in enumerate(paper.get("figures_and_tables", [])):
            parts.append(f"[float-{fi}] {figure['file']}: {figure.get('caption', '')}")
        path.write_text("\n\n".join(parts) + "\n", encoding="utf-8")
    # Exact original selected records for official evaluator interoperability.
    selected_qids = {task["gold"]["question_id"] for task in tasks}
    subset = {pid: {**data[pid], "qas": [qa for qa in data[pid]["qas"] if qa["question_id"] in selected_qids]}
              for pid in paper_ids}
    write_json(out / "qasper_selected_original.json", subset)
    return tasks, {"split": "dev-v0.3", "population_papers": len(data),
                   "population_questions": sum(len(paper["qas"]) for paper in data.values()),
                   "eligible": len(eligible), "invalid_annotation_ids": invalid,
                   "selection": [task["id"] for task in tasks], "arxiv_ids": paper_ids,
                   "reference_type_counts": dict(Counter(ref["type"] for task in tasks for ref in task["gold"]["references"]))}


def fetch_pdfs(out: Path, paper_ids: list[str], timeout: float) -> dict:
    status = {}
    last_finished = 0.0
    for paper_id in paper_ids:
        relative = f"original_pdfs/{paper_id}.pdf"
        path = out / relative
        url = f"https://arxiv.org/pdf/{paper_id}"
        if path.exists() and path.read_bytes().startswith(b"%PDF-"):
            data = path.read_bytes()
            status[paper_id] = {"status": "downloaded", "path": relative, "url": url,
                                "sha256": sha256(data), "bytes": len(data)}
            continue
        # At least three seconds after each completed request, including failures.
        elapsed = time.monotonic() - last_finished
        if elapsed < 3.0:
            time.sleep(3.0 - elapsed)
        try:
            data = fetch(url, timeout)
            if not data.startswith(b"%PDF-"):
                raise ValueError("response is not a PDF")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            status[paper_id] = {"status": "downloaded", "path": relative, "url": url,
                                "sha256": sha256(data), "bytes": len(data)}
        except Exception as error:
            status[paper_id] = {"status": "missing", "url": url,
                                "error": f"{type(error).__name__}: {error}", "selection_replaced": False}
        last_finished = time.monotonic()
        print(json.dumps({"arxiv_id": paper_id, **status[paper_id]}), flush=True)
        write_json(out / "pdf_download_status.json", status)
    return status


def verify(out: Path) -> None:
    manifest = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    for source in manifest["sources"].values():
        if sha256((out / "raw" / source["file"]).read_bytes()) != source["sha256"]:
            raise ValueError(f"Raw release integrity check failed: {source['file']}")
    for relative, expected in manifest["frozen_files_sha256"].items():
        path = out / relative
        if sha256(path.read_bytes()) != expected:
            raise ValueError(f"Integrity check failed: {relative}")
    rows = [json.loads(line) for line in (out / "pilot50.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(rows) == 50 and len({row["id"] for row in rows}) == 50
    assert Counter(row["suite"] for row in rows) == {"scifact": 30, "qasper": 20}
    inputs = [json.loads(line) for line in (out / "inputs.jsonl").read_text(encoding="utf-8").splitlines()]
    assert all("gold" not in row for row in inputs)
    assert [row["id"] for row in rows] == [row["id"] for row in inputs]
    for row in rows:
        assert all((out / path).is_file() for path in row["papers"])
        if row["suite"] == "qasper":
            refs = [qasper_reference(a) for a in row["gold"]["annotations"]]
            assert row["gold"]["answers"] == [r["answer"] for r in refs if r is not None]
    optional_pdfs_verified = 0
    optional_pdfs_omitted = 0
    for value in manifest.get("pdf_download_status", {}).values():
        if value["status"] == "downloaded":
            pdf_path = out / value["path"]
            if not pdf_path.is_file():
                # The licensed text-input bundle intentionally omits original
                # paper PDFs. They are not model inputs in this protocol.
                optional_pdfs_omitted += 1
                continue
            data = pdf_path.read_bytes()
            assert data.startswith(b"%PDF-") and sha256(data) == value["sha256"]
            optional_pdfs_verified += 1
    print(json.dumps({"verified": True, "tasks": len(rows), "frozen_files": len(manifest["frozen_files_sha256"]),
                      "optional_pdfs_verified": optional_pdfs_verified, "optional_pdfs_omitted": optional_pdfs_omitted}))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "public_benchmarks")
    parser.add_argument("--fetch-pdfs", action="store_true", help="Also attempt each selected original arXiv PDF; never replace missing items")
    parser.add_argument("--pdf-timeout", type=float, default=30.0)
    parser.add_argument("--verify", action="store_true", help="Offline integrity verification only")
    args = parser.parse_args()
    out = args.out.resolve()
    if args.verify:
        verify(out)
        return
    scifact_tasks, scifact_info = build_scifact(out, raw_release(out, "scifact"))
    qasper_tasks, qasper_info = build_qasper(out, raw_release(out, "qasper"))
    tasks = scifact_tasks + qasper_tasks
    write_jsonl(out / "pilot50.jsonl", tasks)
    write_jsonl(out / "inputs.jsonl", [{key: value for key, value in task.items() if key != "gold"} for task in tasks])
    write_json(out / "selection.json", {"seed": SEED, "method": "Per suite: sort eligible task IDs, random.Random(seed).sample, sort selected IDs",
                                        "scifact": scifact_info, "qasper": qasper_info})
    pdf_status_path = out / "pdf_download_status.json"
    if pdf_status_path.exists():
        pdf_status = json.loads(pdf_status_path.read_text(encoding="utf-8"))
    else:
        pdf_status = {pid: {"status": "not_attempted", "url": f"https://arxiv.org/pdf/{pid}"} for pid in qasper_info["arxiv_ids"]}
    frozen = [out / "pilot50.jsonl", out / "inputs.jsonl", out / "selection.json", out / "qasper_selected_original.json"]
    frozen.extend(sorted((out / "documents").rglob("*.md")))
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(), "seed": SEED,
        "counts": {"scifact": 30, "qasper": 20}, "sources": SOURCES,
        "implementation_inspiration": "computersniper/glossX eval/glossx_eval/prepare.py and tasks.py",
        "official_qasper_evaluator": "https://github.com/allenai/qasper-led-baseline/blob/main/scripts/evaluator.py",
        "scifact_protocol": "Closed-document oracle cited-abstract classification, not SciFact open-corpus retrieval or its complete official leaderboard protocol. Gold labels map SUPPORT=>SUPPORTED, CONTRADICT=>REFUTED; no evidence=>NOT ENOUGH EVIDENCE.",
        "qasper_protocol": "QASPER v0.3 dev, one released-text document per question. Annotation alternatives kept separate; answers follow the official evaluator. Markdown carries S2ORC text and captions, not figure/table image contents, original pages, or bounding boxes.",
        "gold_security": "inputs.jsonl contains no gold. Stage only a question and its papers into each agent workspace; never expose raw releases, pilot50.jsonl, selected-original JSON, selection or manifest with gold-derived counts to agents.",
        "pdf_protocol": "Optional unversioned arXiv PDFs may differ from released S2ORC text. Download failures retain selected question IDs. Downloaded PDFs are reference assets; pilot50 always uses the same frozen Markdown inputs. Page/span support requires separate original-PDF adjudication.",
        "pdf_download_status": pdf_status,
        "missing_pdf_ids": [pid for pid, value in pdf_status.items() if value["status"] != "downloaded"],
        "frozen_files_sha256": {path.relative_to(out).as_posix(): sha256(path.read_bytes()) for path in frozen},
    }
    # Commit the full text pilot and its hashes before slow optional downloads.
    write_json(out / "manifest.json", manifest)
    verify(out)
    if args.fetch_pdfs:
        pdf_status = fetch_pdfs(out, qasper_info["arxiv_ids"], args.pdf_timeout)
        write_json(pdf_status_path, pdf_status)
        manifest["pdf_download_status"] = pdf_status
        manifest["missing_pdf_ids"] = [pid for pid, value in pdf_status.items() if value["status"] != "downloaded"]
        write_json(out / "manifest.json", manifest)
        print(json.dumps({"pdfs_downloaded": sum(value["status"] == "downloaded" for value in pdf_status.values()),
                          "pdfs_missing": len(manifest["missing_pdf_ids"])}))


if __name__ == "__main__":
    main()
