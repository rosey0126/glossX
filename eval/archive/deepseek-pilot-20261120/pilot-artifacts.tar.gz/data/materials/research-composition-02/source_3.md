# Controlled research case research-composition-02

Synthetic evaluation material; not a real publication.

## Page 1

Method B results. Easy cases: 900 observations, 87% correct. Hard cases: 100 observations, 17% correct. The pooled headline did not adjust for case difficulty.
