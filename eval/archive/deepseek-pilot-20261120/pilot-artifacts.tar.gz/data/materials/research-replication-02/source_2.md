# Controlled research case research-replication-02

Synthetic evaluation material; not a real publication.

## Page 1

Run log. Seed 1: A=72, B=72. Seed 2: A=74, B=73. Seed 3: A=73, B=74. Values are accuracies in percent. No runs were dropped.
