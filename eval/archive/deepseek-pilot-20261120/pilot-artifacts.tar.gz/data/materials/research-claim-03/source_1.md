# Controlled research case research-claim-03

Synthetic evaluation material; not a real publication.

## Page 1

Trial-3 claim registration. In the benchmark's English held-out corpus, A has lower error than B. This claim does not cover other languages or clinical deployment.
