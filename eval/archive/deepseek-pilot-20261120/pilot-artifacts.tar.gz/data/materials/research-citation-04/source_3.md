# Controlled research case research-citation-04

Synthetic evaluation material; not a real publication.

## Page 1

Energy appendix. No energy or power measurements were collected for either method. The appendix discusses possible future measurements only; it does not report an energy reduction.
