# Controlled research case research-multiplicity-02

Synthetic evaluation material; not a real publication.

## Page 1

Results. Ordered p-values are H1=0.0084, H2=0.0184, H3=0.0314, H4=0.0492. All four tests belong to the registered family.
