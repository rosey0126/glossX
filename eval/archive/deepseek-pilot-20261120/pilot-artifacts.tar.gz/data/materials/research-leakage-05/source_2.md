# Controlled research case research-leakage-05

Synthetic evaluation material; not a real publication.

## Page 1

Provenance audit. Exactly 13 of the held-out patient identifiers also occur in training. The remaining held-out patients do not occur in training. No per-patient predictions were retained.
