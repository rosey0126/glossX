# Controlled research case research-claim-04

Synthetic evaluation material; not a real publication.

## Page 1

The held-out evaluation found a higher error rate for A than B. This contradicts the direction of the registered claim.
