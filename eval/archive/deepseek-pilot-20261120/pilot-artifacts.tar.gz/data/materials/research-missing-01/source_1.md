# Controlled research case research-missing-01

Synthetic evaluation material; not a real publication.

## Page 1

Study registration. This observational study enrolled 120 participants. Treatment assignment was not randomized. The planned report would include adjusted effect estimates and confidence intervals in Appendix B.
