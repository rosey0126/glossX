# Controlled research case research-metrics-03

Synthetic evaluation material; not a real publication.

## Page 1

Confusion matrix. True positive: 27. False positive: 7. False negative: 11. True negative: 61. Each test observation appears in exactly one cell.
