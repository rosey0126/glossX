# Controlled research case research-replication-01

Synthetic evaluation material; not a real publication.

## Page 1

Run log. Seed 1: A=71, B=71. Seed 2: A=73, B=72. Seed 3: A=72, B=73. Values are accuracies in percent. No runs were dropped.
