# Controlled research case research-replication-01

Synthetic evaluation material; not a real publication.

## Page 1

Draft comparison. A's reported result is its best seed, 73%, while B's reported result is its mean. The draft describes this as an unbiased paired mean comparison.
