# Controlled research case research-metrics-01

Synthetic evaluation material; not a real publication.

## Page 1

Manuscript draft. We calculated macro-F1 as (TP+TN)/(TP+FP+FN+TN). No class averaging was performed. The draft has not been corrected.
