# Controlled research case research-metrics-01

Synthetic evaluation material; not a real publication.

## Page 1

Confusion matrix. True positive: 25. False positive: 5. False negative: 9. True negative: 63. Each test observation appears in exactly one cell.
