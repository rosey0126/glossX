# Controlled research case research-budget-01

Synthetic evaluation material; not a real publication.

## Page 1

Trial-1 registered comparison. Eligibility requires the same dataset, split, and exactly 100 GPU-hours of training. Accuracy is reported in percent.
