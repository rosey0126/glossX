# Controlled research case research-budget-01

Synthetic evaluation material; not a real publication.

## Page 1

Matched-budget results. Method A used 100 GPU-hours and achieved 77% accuracy. Method B used 100 GPU-hours and achieved 75% accuracy. Both used the registered held-out split.
