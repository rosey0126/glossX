# Controlled research case research-multiplicity-04

Synthetic evaluation material; not a real publication.

## Page 1

Results. Ordered p-values are H1=0.0088, H2=0.0188, H3=0.0318, H4=0.0494. All four tests belong to the registered family.
