# Controlled research case research-leakage-01

Synthetic evaluation material; not a real publication.

## Page 1

Reported experiment. The aggregate held-out accuracy was 84%. Feature normalization was fitted on the union of training and held-out records before the split. Only the aggregate score is available.
