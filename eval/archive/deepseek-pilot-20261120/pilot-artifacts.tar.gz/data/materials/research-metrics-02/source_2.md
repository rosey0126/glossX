# Controlled research case research-metrics-02

Synthetic evaluation material; not a real publication.

## Page 1

Confusion matrix. True positive: 26. False positive: 6. False negative: 10. True negative: 62. Each test observation appears in exactly one cell.
