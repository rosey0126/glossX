# Controlled research case research-composition-01

Synthetic evaluation material; not a real publication.

## Page 1

Method B results. Easy cases: 900 observations, 86% correct. Hard cases: 100 observations, 16% correct. The pooled headline did not adjust for case difficulty.
