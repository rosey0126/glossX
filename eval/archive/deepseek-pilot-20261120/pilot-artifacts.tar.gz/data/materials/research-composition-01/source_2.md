# Controlled research case research-composition-01

Synthetic evaluation material; not a real publication.

## Page 1

Method A results. Easy cases: 100 observations, 91% correct. Hard cases: 900 observations, 21% correct. Each stratum has equal weight within itself.
