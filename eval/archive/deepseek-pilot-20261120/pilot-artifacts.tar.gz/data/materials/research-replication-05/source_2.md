# Controlled research case research-replication-05

Synthetic evaluation material; not a real publication.

## Page 1

Run log. Seed 1: A=75, B=75. Seed 2: A=77, B=76. Seed 3: A=76, B=77. Values are accuracies in percent. No runs were dropped.
