# Controlled research case research-budget-02

Synthetic evaluation material; not a real publication.

## Page 1

Trial-2 registered comparison. Eligibility requires the same dataset, split, and exactly 100 GPU-hours of training. Accuracy is reported in percent.
