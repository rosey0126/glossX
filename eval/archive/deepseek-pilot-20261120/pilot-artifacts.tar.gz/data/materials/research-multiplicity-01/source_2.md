# Controlled research case research-multiplicity-01

Synthetic evaluation material; not a real publication.

## Page 1

Results. Ordered p-values are H1=0.0082, H2=0.0182, H3=0.0312, H4=0.0491. All four tests belong to the registered family.
