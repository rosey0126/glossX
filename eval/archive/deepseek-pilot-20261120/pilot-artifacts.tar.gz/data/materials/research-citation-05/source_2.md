# Controlled research case research-citation-05

Synthetic evaluation material; not a real publication.

## Page 1

Evaluation record 5. Method A outperformed Method B on the held-out English corpus. No Spanish corpus was evaluated. The training and held-out corpora were disjoint.
