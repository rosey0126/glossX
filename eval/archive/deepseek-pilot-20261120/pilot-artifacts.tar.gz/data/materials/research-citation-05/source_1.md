# Controlled research case research-citation-05

Synthetic evaluation material; not a real publication.

## Page 1

Evidence audit rule. A citation must support the exact population, comparison and quantity in the claim. A genuine quotation can still fail to support the associated claim.
