# 数据来源与许可

本包的任务经过抽样、转为 Markdown，保留了原始 ID、出处与哈希。自建合成任务由本次协作编写，明确与真实论文、公开基准分开。

## SciFact

David Wadden、Shanchuan Lin、Kyle Lo、Lucy Lu Wang、Madeleine van Zuylen、Arman Cohan、Hannaneh Hajishirzi，2020，Fact or Fiction: Verifying Scientific Claims。

- 原作者仓库：<https://github.com/allenai/scifact>
- 许可说明：<https://github.com/allenai/scifact/blob/master/LICENSE.md>
- claim 与标注：CC BY 4.0，<https://creativecommons.org/licenses/by/4.0/>
- corpus 文献摘要：ODC Attribution 1.0，<https://opendatacommons.org/licenses/by/1-0/>
- 上游代码：Apache 2.0。

本包只给出固定子集和 Markdown 转换，不代表作者认可本实验。

## QASPER

Pradeep Dasigi、Kyle Lo、Iz Beltagy、Arman Cohan、Noah A. Smith、Matt Gardner，2021，A Dataset of Information-Seeking Questions and Answers Anchored in Research Papers。

- 作者仓库和评价脚本：<https://github.com/allenai/qasper-led-baseline>
- Ai2 官方数据卡：<https://huggingface.co/datasets/allenai/qasper>
- 数据卡标记许可：CC BY 4.0，<https://creativecommons.org/licenses/by/4.0/>

作者级参考答案分别保存，没有跨标注者拼接金标。本包转换了发布正文与图表 caption；不含图表像素，不能替代原论文 PDF 的所有信息。

## 原论文 PDF 与软件

QASPER 数据集许可不自动替代原论文逐篇/逐版本的版权许可。共享压缩包不包含下载的 arXiv PDF；保留论文 ID、获取脚本、URL 和哈希。本地 original_pdfs 仅用于后续核验。arXiv 许可说明：<https://info.arxiv.org/help/license/index.html>。

DSH 使用官方 npm 固定版本，依赖通过 lockfile 安装，不在共享包中再分发 node_modules。软件来源：<https://github.com/deepseek-ai/deepseek-harness>。GlossX 源码通过用户提供的仓库获取，保留 Git 提交号；共享包不再分发整个源码 checkout，复现时从 <https://github.com/computersniper/glossX> 获取相同版本。
