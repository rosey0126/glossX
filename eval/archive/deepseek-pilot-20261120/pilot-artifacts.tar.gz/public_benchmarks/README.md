# 公开科研任务试点

这里有 **SciFact dev 30 条 + QASPER dev v0.3 20 条**，来自官方发布数据，包含原始人工金标。抽样种子是 `20261120`；先按任务 ID 排序，再在每个数据集内固定种子抽样。没有按系统表现筛题，也没有因原 PDF 下载失败换题。

在 `glossx_dsh_eval` 目录执行：

```powershell
python prepare_public.py --verify
python prepare_public.py --fetch-pdfs
```

第二条会验证原始压缩包哈希、重建同一批任务，并尝试下载缺失原 PDF。arXiv 请求逐个执行，每次请求结束后至少间隔 3 秒；Python CA 不完整时使用仍然开启证书校验的 Windows 原生 curl。整个准备过程不调用模型。

| 文件 | 用途 |
| --- | --- |
| `inputs.jsonl` | 无答案的任务列表，只可将当前题与其材料交给被测系统 |
| `pilot50.jsonl` | 评测端使用，含 gold，不可交给被测系统 |
| `documents/` | 所有 50 题的输入材料，已完整准备并冻结 SHA256 |
| `selection.json` | 抽样总体、选中 ID、类型数量与抽样规则 |
| `manifest.json` | 原始 URL、哈希、协议限制、输入文件哈希与 PDF 状态 |
| `qasper_selected_original.json` | 选中问题的原始 QASPER 结构，可直接交给官方 evaluator；含答案 |
| `original_pdfs/` | 可选的 QASPER 原论文参考文件；不改变当前 Markdown 输入协议 |
| `pdf_download_status.json` | 原 PDF 逐个下载结果，不代表模型运行结果 |

SciFact 输入是该论断的 cited abstracts，正文逐句保留原始零基句号索引。这是 **closed-document / oracle cited-abstract 分类**，不包含全语料检索，不能称为 SciFact 官方完整任务或排行榜分数。`gold.label` 方便现有评分器计算三分类 accuracy / macro-F1；原文证据句集合仍在 `gold.evidence`。30 条内标签为 SUPPORTED 12、REFUTED 5、NOT ENOUGH EVIDENCE 13；这是随机抽样结果，没有人为均衡。

QASPER 输入是发布包的 S2ORC 正文、摘要及图表标题。Markdown 是文字 sidecar，**不是原 PDF**；`[sX-pY]` 是段落定位标识，不是 PDF 页码。表格和图片的像素内容未包含在 Markdown 中，涉及它们的题仍保留，可能影响成绩。`gold.answers` 的每个条目只来自一位标注者；完整 `gold.references`、`gold.annotations` 保留逐标注者答案与证据。参考答案依照官方 evaluator 的规则处理，不跨标注者拼接。答案 F1 取标注候选中的最大 token F1；Evidence F1 应逐候选算段落 F1 再取最大，不能把所有人的证据合并成一个金标。

arXiv 下载地址没有锁定论文版本，下载的现版原 PDF 可能与发布包正文不同；逐个文件哈希写入 manifest。论文的页码支持、引用蕴含与原 PDF 对照仍需单独核验。若另开 PDF 实验，两套系统必须使用同一文件、同一抽样，并与本目录的 released-text 实验分开报告。

本次选中的 20 份 QASPER 原论文 PDF 已全部下载，缺失 0 份；具体哈希见 manifest。随机抽中的 2 条 QASPER 问题有标注者选用图表证据，解释 released-text 协议结果时需保留这项限制。

不要把 `raw/`、`pilot50.jsonl`、`qasper_selected_original.json` 或 gold 派生信息放进代理可读工作区。每题只复制该题文件和材料；数据集、评分器和汇总在代理隔离范围之外保留。失败、超时和未作答保留在最终分母中。公开 dev 集有污染可能，50 条只支持试点结论，不能据此保证某系统更好。

数据与算法来源：

- [SciFact 官方仓库](https://github.com/allenai/scifact)；[原始发布包](https://scifact.s3-us-west-2.amazonaws.com/release/latest/data.tar.gz)。Wadden et al., *Fact or Fiction: Verifying Scientific Claims*, EMNLP 2020。
- [QASPER 官方项目](https://github.com/allenai/qasper-led-baseline)；[v0.3 原始发布包](https://qasper-dataset.s3.us-west-2.amazonaws.com/qasper-train-dev-v0.3.tgz)；[官方 evaluator](https://github.com/allenai/qasper-led-baseline/blob/main/scripts/evaluator.py)。Dasigi et al., *A Dataset of Information-Seeking Questions and Answers Anchored in Research Papers*, NAACL 2021。
- 准备流程参考项目已有的 `glossX/eval/glossx_eval/prepare.py` 与 `tasks.py`，本实现保留失败项和逐标注者真值。

本目录是任务与材料交付，**没有 DSH 或 GlossX 的实跑分数**。
