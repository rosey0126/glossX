# GlossX 与 DSH 实测结果

以下保留失败与超时。可核验的格式、分类、数值与引文定位分开报告；引句匹配不等于语义支持。

## GlossX-DSH-Controlled-50-v1 / dsh

运行 40 次，题目 ID 共 40 条；成功返回 39 次。

- core_correct: 0.9000 (运行平均)
- format_valid: 0.9000 (运行平均)
- decision_correct: 0.9500 (运行平均)
- numeric_accuracy: 0.9250 (运行平均)
- quote_grounding: 0.9500 (运行平均)
- evidence_document_coverage: 0.9500 (运行平均)
- structured_pass: 0.8500 (运行平均)
- mean_latency_s: 10.796

## GlossX-DSH-Controlled-50-v1 / glossx

运行 40 次，题目 ID 共 40 条；成功返回 37 次。

- core_correct: 0.8750 (运行平均)
- format_valid: 0.9000 (运行平均)
- decision_correct: 0.9250 (运行平均)
- numeric_accuracy: 0.9042 (运行平均)
- quote_grounding: 0.9208 (运行平均)
- evidence_document_coverage: 0.9250 (运行平均)
- structured_pass: 0.8250 (运行平均)
- mean_latency_s: 9.259

## qasper / dsh

运行 20 次，题目 ID 共 20 条；成功返回 19 次。

- format_valid: 0.9000 (运行平均)
- answer_f1: 0.1082 (运行平均)
- exact_match: 0.0000 (运行平均)
- mean_latency_s: 9.632

## qasper / glossx

运行 20 次，题目 ID 共 20 条；成功返回 12 次。

- format_valid: 0.6000 (运行平均)
- answer_f1: 0.0675 (运行平均)
- exact_match: 0.0000 (运行平均)
- mean_latency_s: 7.873

## scifact / dsh

运行 30 次，题目 ID 共 30 条；成功返回 27 次。

- format_valid: 0.9000 (运行平均)
- label_correct: 0.7333 (运行平均)
- mean_latency_s: 9.080

SciFact 三分类指标（失败保留在分母）：{"accuracy": 0.7333333333333333, "macro_f1": 0.7775362318840581, "n": 30}

## scifact / glossx

运行 30 次，题目 ID 共 30 条；成功返回 20 次。

- format_valid: 0.6667 (运行平均)
- label_correct: 0.4667 (运行平均)
- mean_latency_s: 6.612

SciFact 三分类指标（失败保留在分母）：{"accuracy": 0.4666666666666667, "macro_f1": 0.5595959595959595, "n": 30}

## 配对差值

完整配对题目 40 条；structured_pass 差值 GlossX − DSH = -0.0250。

按任务族聚类 bootstrap 的探索性 95% 区间 [-0.1750, 0.1250]。同族实例不视为独立研究任务。

质量核验仍需匿名人工审阅解释是否成立、引文是否支持论断。运行环境/工具或参数不完全一致时，只能比较本次系统配置。缺失 token/成本不作推算。
